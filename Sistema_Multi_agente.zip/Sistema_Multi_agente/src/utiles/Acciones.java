package utiles;

/**
 *
 * @author juanmi
 */

public enum Acciones {
    ARR, ABA, IZQ, DER, ARRIZQ, ARRDER, ABAIZQ, ABADER; 
}
