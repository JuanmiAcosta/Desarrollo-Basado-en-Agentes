package estados;

/**
 *
 * @author juanmi
 */
public enum EstadosSkal {
    ESPERANDO_MENSAJE_INICIO, ESPERANDO_JARL_INICIO;
}
