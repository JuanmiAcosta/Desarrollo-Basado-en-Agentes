package estados;

/**
 *
 * @author juanmi
 */
public enum EstadosVidente {
    ESPERANDO_PETICION_COORD;
}
