package estados;

/**
 *
 * @author juanmi
 */
public enum EstadosJarl {
    ESPERANDO_ENVIO_BARCO, ESPERANDO_RESP_SKAL, ESPERANDO_LLEGADA_BARCO;
}
